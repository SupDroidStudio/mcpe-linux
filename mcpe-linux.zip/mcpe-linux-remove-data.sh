#!/bin/bash
#
# Greeting message.
echo "The data of Minecraft: Bedrock Edition will be removed from your system."
sleep 3
# Ensure we are not running with superuser privileges.
if [[ $EUID = "0" ]]; then
  echo "This script must NOT be run as 'root' or with 'sudo'. Exiting..."
  exit 1
fi
echo
# Begin removal.
cd ~/.local/share
echo "Removing data..."
rm -rf msa
rm -rf msa-ui-qt
rm -rf mcpelauncher
rm -rf "Minecraft Linux Launcher"
sleep 1
echo
echo "Data of Minecraft: Bedrock Edition has now been completely removed."
cd ~
exit 0
