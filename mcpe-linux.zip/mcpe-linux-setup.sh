#!/bin/bash
#
# mcpe-linux setup script, from https://github.com/SupDroidStudio/mcpe-linux.
#
# Abort setup is a command fails. This prevents broken or half installations.
set -e
# Greeting message.
echo "This script will set up and install Minecraft: Bedrock Edition on your"
echo "Debian-based Linux device. Current Version: 2.3 - 'NoLongerSupported'."
echo "Written by SupDroid Studio, with credit to MrArm, the creator of the"
echo "launcher itself."
echo
sleep 1
# Ensure we have superuser privileges.
if [ $EUID -ne "0" ]; then
  echo "This script must be run as the 'root' user or with 'sudo'. Exiting..."
  exit 1
fi
echo "<<< IMPORTANT NOTICE! >>>"
echo
echo "This script is now deprecated. The launcher that is installed by this"
echo "script does not work with Minecraft versions of 1.13 or higher."
echo "Should you wish to play versions 1.13 or higher, please navigate to"
echo "https://github.com/ChristopherHX/linux-packaging-scripts/releases/tag/appimage"
sleep 1
echo
echo "From this link there are instructions for how to install a fork of the"
echo "launcher which supports all the latest versions. It is also in AppImage"
echo "format which makes installation easier and faster."
sleep 1
echo
echo "Press CTRL+C to cancel now, or setup will proceed in 15 seconds..."
sleep 15
echo
echo "Sorry to bother again, but using this script is highly discouraged"
echo "because of the reasons stated above."
echo
read -p "Last chance, press CTRL+C to cancel or press ENTER to continue: "
echo
# Install dependencies.
echo "Install dependencies [this may take a while]:"
echo
dpkg --add-architecture i386
apt-get update
apt-get install git cmake pkg-config libssl-dev libcurl4-openssl-dev qtbase5-dev qtwebengine5-dev g++-multilib libpng-dev:i386 libx11-dev:i386 libxi-dev:i386 libcurl4-openssl-dev:i386 libudev-dev:i386 libevdev-dev:i386 libegl1-mesa-dev:i386 libasound2:i386 libssl-dev libcurl4-openssl-dev libuv1-dev libzip-dev libprotobuf-dev protobuf-compiler qtbase5-dev qtwebengine5-dev qtdeclarative5-dev libqt5svg5-dev qml-module-qtquick2 qml-module-qtquick-layouts qml-module-qtquick-controls qml-module-qtquick-controls2 qml-module-qtquick-window2 qml-module-qtquick-dialogs qml-module-qt-labs-settings qml-module-qt-labs-folderlistmodel libpulse0 libpulse0:i386 -y
sleep 1
# Create and change to a clean, working directory.
mkdir -p ~/.mcpe-linux-tmp
cd ~/.mcpe-linux-tmp
echo
# Begin the build.
echo "Install the MSA client [for Xbox Live support]:"
echo
git clone --recursive https://github.com/minecraft-linux/msa-manifest.git msa
cd msa
mkdir -p build
cd build
# This cmake option enables the graphical UI for Xbox Live login.
cmake -DENABLE_MSA_QT_UI=ON ..
# It's safe to enable 12 parallel processes. Even on a single core system it is
# extremely unlikely to overheat the CPU or run the system out of memory, since
# each individual build job is very small. Change to '-j1' if you prefer not to
# parallel build, however this will substancially increase the build time.
make -j12
make install
cd ../..
sleep 1
echo
echo "Install the Game Launcher:"
echo
git clone --recursive https://github.com/minecraft-linux/mcpelauncher-manifest.git mcpelauncher
cd mcpelauncher
mkdir -p build
cd build
cmake ..
make -j12
make install
cd ../..
sleep 1
echo
echo "Install the Qt UI:"
echo
git clone --recursive https://github.com/minecraft-linux/mcpelauncher-ui-manifest.git mcpelauncher-ui
cd mcpelauncher-ui
mkdir -p build
cd build
cmake ..
make -j12
make install
sleep 1
cd ~
echo
echo "Cleaning up from the installation..."
# Comment this out if you'd prefer the build files to remain (not recommended
# and will most likely cause future installs/reinstalls to fail).
rm -rf ~/.mcpe-linux-tmp
sleep 0.5
echo
echo "Setup successful!"
sleep 1
echo
echo "Please find the launcher in your apps list (under the 'Games' category"
echo "on some desktop environments). From there you'll need to sign in to"
echo "Google Play. If you don't own Minecraft on Google Play, please visit"
echo "http://bit.ly/mcpe-linux-zip where you can download the versions manually."
sleep 2
echo
echo "If you need help or support, please contact us at supdroid@mail.uk, or"
echo "open an issue on the Github repo. Furthermore, you can also join the"
echo "Discord server of our gaming division, The Sonic Master and ask for help"
echo "in the #support channel."
sleep 2
echo
echo "Additionally, there is a bug affecting MCPE versions 1.13+ preventing the"
echo "game from running. Until it's resolved, please use version 1.12.1, which"
echo "can be specified by configuring profile settings in the launcher."
sleep 2
echo
echo "To uninstall Minecraft, run the uninstall script as root or with sudo."
exit 0
